go build -o ./bin/dcmp
./bin/dcmp
