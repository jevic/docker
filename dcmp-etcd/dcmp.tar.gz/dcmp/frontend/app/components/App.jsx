import React from 'react';
import Header from '../common/Header'
import Dcmp from './Dcmp'

class App extends React.Component {
  render() {
    return (
    	<div>
      		<Header/>
      		<Dcmp />
      	</div>
      );
  }
}

export default App;
